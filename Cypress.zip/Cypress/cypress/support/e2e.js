import './commands';
// import 'cypress-allure-plugin';
import '@shelex/cypress-allure-plugin';
